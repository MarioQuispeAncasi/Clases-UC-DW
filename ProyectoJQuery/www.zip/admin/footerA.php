    <div class="row footer">
        <h1 class="text-center bg-dark text-light" style="padding: 35px; margin: 0px;">Todos los derechos reservados &copy; <?php echo $anioAplicacion ?></h1>
    </div>
</body>
</html>