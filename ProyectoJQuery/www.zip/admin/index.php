<?php
    header("location:/admin/variables/index.php");
?>