insert into variables (cNombreVariable, cValorVariable, cDescripcion, lVigente) 
	values ('cNombreEmpresa', 'Dulce Cafe', 'Nombre de la Empresa', 1),
    ('cAnioAplicacion','2023', 'Anio de Registro de la aplicacion',1),
    ('cTituloBan1', 'Primer Mensaje de la Aplicacion', 'Titulo del primer banner', 1),
    ('cTituloBan2', 'Segundo Mensaje de la Aplicacion', 'Titulo del segundo banner', 1),
    ('cTituloBan3', 'Tercer Mensaje de la Aplicacion', 'Titulo del tercer banner', 1),    
    ('cLogoEmpresa', 'xxxxxx', 'Logo de la Empresa', 1);

---------------------------------------------------------------------------------------------------------------------------------------------------
